from django.contrib import admin
from django.urls import path, include
from . import views
from .views import PostView, ArticleDetailView, AddPostView, UpdatePostView, DeletePostView, UserEditView, AddCommentView


urlpatterns =   [
    
    path('', views.home, name="home"),
    path('posts/', PostView.as_view(), name="posts"),
    path('article/<int:pk>', ArticleDetailView.as_view(), name='article-detail'),
    path('signup/', views.signup, name="signup"),
    path('signin/', views.signin, name="signin"),
    path('signout/', views.signout, name="signout"),
    path('add_post/', AddPostView.as_view(), name='add_post'),
    path('article/edit/<int:pk>', UpdatePostView.as_view(), name='update_post'),
    path('article/<int:pk>/remove', DeletePostView.as_view(), name='delete_post'),
    path('activate/<uid64>/<token>', views.signout, name="activate"),
    path('edit_profile/', UserEditView.as_view(), name = "edit_profile"),
    path('article/<int:pk>/comment/', AddCommentView.as_view(), name='add_comment'),

    
] 