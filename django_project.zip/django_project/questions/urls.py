from django.contrib import admin
from django.urls import path
from .views import *

app_name = 'questions'  # This line defines the app namespace

urlpatterns = [
    path('quiz_home/', quiz_home,  name="quiz_home"),
    path('<id>', take_quiz, name='take_quiz'),
    path('api/<id>', api_question, name = "api_question"),

]